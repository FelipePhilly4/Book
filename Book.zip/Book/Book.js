class Book {
    constructor ( title, author, pages, description, currentPage, read){
        this.title = title;
        this.author = author;
        this.pages = pages;
        this.description = description;
        this.currentPage = currentPage;
        this.read = read;
    }
    readBook (pageNumber){
        if (currentPage !== pageNumber){
            console.log("Wrong page");
        } else if (currentPage === pageNumber){
            this.currentPage = pageNumber;
        } else if (currentPage === this.pages){
            this.read = 'Livre lu';
        }
    }
} 

 