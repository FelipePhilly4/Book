// import { Book } from './Book.js';

let bookList = [];

let firstBook = new Book (
    "Balzac et la petite tailleuse chinoise",
    "Dai Sijie",
    300,
    "Roman écrit par le cinéaste chinois paru en 2000",
    244,
 
)

let secondBook = new Book (
    "Les trois mousquetaires ",
    "Alexandre Dumas",
    800,
    "Roman écrit par Alexandre Dumas",
    800,
    
)

let thirdBook = new Book (
    "20 ans après",
    "Alexandre Dumas",
    700,
    "Roman écrit par Alexandre Dumas",
    34,
    
)

bookList.push(firstBook, secondBook, thirdBook);
 
// export { bookList };